package com.example.codepathmail

class Email(
    val sender: String,
    val title: String,
    val summary: String) {
}