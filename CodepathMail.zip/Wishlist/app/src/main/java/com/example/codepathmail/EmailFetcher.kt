package com.example.codepathmail

class EmailFetcher {
    companion object {
        val senders = listOf("")
        val title = listOf("")
        val summary = listOf("")
        fun getEmails(): MutableList<Email> {
            var emails : MutableList<Email> = ArrayList()
            for (i in 0..9) {
                val email = Email(senders[i], title[i], summary[i])
                emails.add(email)
            }
            return emails
        }

        fun getNext5Emails(): MutableList<Email> {
            var newEmails : MutableList<Email> = ArrayList()
            for (i in 10..14) {
                val email = Email(senders[i], title[i], summary[i])
                newEmails.add(email)
            }
            return newEmails
        }
    }
}